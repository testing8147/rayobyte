export const getRoundOffValue = (number: number) => {
  return Math.round(number * 100) / 100;
};
