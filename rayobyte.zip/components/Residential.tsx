import React from "react";

type CounterProps = {
  resedentialInput: number;
  handleChangeResidentialProxies: any;
};

function Residential({
  resedentialInput,
  handleChangeResidentialProxies,
}: CounterProps) {
  return (
    <div>
      <div className="two-cols">
        <div></div>
        <div>
          <div className="proxy_box">
            <div className="inner_proxy_box">
              <input
                type="radio"
                id="test2"
                defaultChecked
                name="radio-group"
              />
              <label htmlFor="test2">Rotating</label>
            </div>
          </div>
        </div>
      </div>

      <div className="no-of-proxies residential-gbs two-cols">
        <div className="lable-box">
          <label>Gigabytes:</label>
        </div>
        
        <div className="content-box">
          <input
            className={`proxy-input ${resedentialInput < 1 && "border-red"}`}
            placeholder=""
            value={resedentialInput}
            onChange={handleChangeResidentialProxies}
            type="number"
            max={1000}
          />
          <br />
          {resedentialInput < 1 && (
            <span className="validation-error">Minimum 1 proxy required</span>
          )}

          <div className="stats">
            <span className="stat-item">
              <b>Starter:</b> <i>1 - 15 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Personal:</b> <i>16 - 49 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Consumer:</b> <i>50 - 99 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Professional:</b> <i>100 - 249 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Business:</b> <i>250 - 499 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Corporate:</b> <i>500 - 999 GB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Enterprise:</b> <i>1 - 4.9 TB</i>{" "}
            </span>
            <span className="stat-item">
              <b>Custom:</b> <i>5TB +</i>{" "}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Residential;
